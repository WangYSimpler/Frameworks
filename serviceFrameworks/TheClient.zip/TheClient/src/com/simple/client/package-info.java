@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.simple.com/")
package com.simple.client;
