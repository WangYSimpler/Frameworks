package com.simple.test;

import com.simple.client.ServiceHello;
import com.simple.client.ServiceHelloService;

/**
*@author WangY
*Oct 23, 2016 5:45:33 PM
*/

public class ServiceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ServiceHello hello =  new ServiceHelloService().getServiceHelloPort();
		String name = hello.getValue("wangyong");
		
		System.out.println(name);
	}
	
	
}
