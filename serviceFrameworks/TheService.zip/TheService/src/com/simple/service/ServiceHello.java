package com.simple.service;

import javax.jws.WebService;
import javax.xml.ws.Endpoint;

/**
*Oct 23, 2016 5:23:11 PM
*@author WangY
*/

@WebService
public class ServiceHello {

	public String getValue(String name)
	{
		return "My name is:" +name;
	}
	
	public static void main(String[] args)
	{
		Endpoint.publish("http://localhost:8080/Service/ServiceHello",	 new ServiceHello());
		System.out.println("Service success");
	}
}
