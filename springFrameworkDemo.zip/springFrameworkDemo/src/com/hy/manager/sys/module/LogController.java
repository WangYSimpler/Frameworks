package com.hy.manager.sys.module;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 登录 controller
 * @author yong
 *
 */
@Controller
@RequestMapping("/system")
public class LogController
{

	private static Logger logger = Logger.getLogger(LogController.class);

	/**
	 * 跳转登录页
	 */
	@RequestMapping(value = "toLogin")
	public String toLogin(HttpServletRequest request)
	{

		return "login";
	}

	/**
	 * 登录
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	
	public String login(HttpServletRequest request, HttpSession session)
	{
		logger.info("登录成功");

		return "manager/sys/main";
	}

	/**
	 * 退出
	 */
	@RequestMapping("/logout")
	@ResponseBody
	public String logout(HttpServletRequest request,HttpServletResponse response,HttpSession session)
	{
		//session.invalidate();
		return "123ABC";
	}

}
